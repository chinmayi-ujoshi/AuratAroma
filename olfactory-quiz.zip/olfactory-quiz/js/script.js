document.addEventListener('DOMContentLoaded', function () {
    // Fetch elements
    const questions = Array.from(document.querySelectorAll('.quiz-question'));
    const progressBar = document.getElementById('progress-bar');
    const resultDiv = document.getElementById('quiz-result');
    const blendName = document.getElementById('blend-name');
    const blendDescription = document.getElementById('blend-description');
    const blendIngredients = document.getElementById('blend-ingredients');
    const nextButton = document.getElementById('next-question');

    // Initialize variables
    let currentQuestionIndex = 0;
    const blendCount = {};

    // Update the progress bar
    function updateProgress() {
        const progress = ((currentQuestionIndex + 1) / questions.length) * 100;
        progressBar.style.width = progress + '%';
    }

    // Show the next question or display the result
    function showNextQuestion() {
        // Validate the current question
        const selectedOption = questions[currentQuestionIndex].querySelector(
            `input[name="question-${currentQuestionIndex}"]:checked`
        );
        if (!selectedOption) {
            alert('Please select an option before proceeding!');
            return;
        }
    
        // Record the selected blend
        const selectedBlend = selectedOption.dataset.blend;
        if (blendCount[selectedBlend]) {
            blendCount[selectedBlend]++;
        } else {
            blendCount[selectedBlend] = 1;
        }
    
        // Hide the current question
        questions[currentQuestionIndex].style.display = 'none';
    
        // Move to the next question or show the result
        currentQuestionIndex++;
        if (currentQuestionIndex < questions.length) {
            // Show the next question
            questions[currentQuestionIndex].style.display = 'block';
            updateProgress();
        } else {
            // Handle the last question and result case
            nextButton.textContent = 'Finish';
            nextButton.removeEventListener('click', showNextQuestion);
            nextButton.addEventListener('click', calculateAndShowResult);
            nextButton.style.display = 'block'; // Ensure the button is visible
        }
    }
    

    // Calculate and display the result
    function calculateAndShowResult() {
        // Determine the blend with the highest count
        const recommendedBlend = Object.keys(blendCount).reduce((a, b) =>
            blendCount[a] > blendCount[b] ? a : b
        );

        // Populate the result using scoringCriteria
        const result = scoringCriteria[recommendedBlend];
        if (result) {
            blendName.textContent = result.name;
            blendDescription.textContent = result.description;
            blendIngredients.textContent = result.ingredients.join(', ');
        }

        // Show the result section
        resultDiv.style.display = 'block';

        // Hide the "Next" button
        nextButton.style.display = 'none';
    }

    // Initialize the quiz
    questions.forEach((q, index) => {
        if (index !== 0) q.style.display = 'none'; // Hide all questions except the first
    });
    updateProgress();

    // Add event listener to the "Next" button
    nextButton.addEventListener('click', showNextQuestion);


    console.log(`Current Question Index: ${currentQuestionIndex}`);
console.log(`Next Button Text: ${nextButton.textContent}`);
console.log(`Next Button Display: ${nextButton.style.display}`);

});
